# OOMS-Project

![MediaPlayerUI](student/src/ui2.PNG)

## To run the player
``` 
Download and install proper java jdk and jre to run the application.
Download the project folder, extact it or clone the project in your system
Double click the executable - student.jar file or open the project in netbeans ide and run
```

# Developers
* Arindam Das Modak [arindam-modak](https://github.com/arindam-modak)
* Yashwardhan Gupta [yash-1998](https://github.com/yash-1998)
* Rishab Agarwal
* Shiv Kumar
* Saurabh Mishra
